(function() {
  // -------------------------
  // MENÚ MÓVIL
  // -------------------------
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const navLinks = document.getElementById('navLinks');

  if (mobileMenuBtn && navLinks) {
    mobileMenuBtn.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  }

  // -------------------------
  // BUSCADOR (OVERLAY)
  // -------------------------
  const searchTrigger = document.getElementById('searchTrigger');
  const searchOverlay = document.getElementById('searchOverlay');
  const closeSearch = document.getElementById('closeSearch');
  const searchInput = document.getElementById('searchInput');

  if (searchTrigger && searchOverlay) {
    searchTrigger.addEventListener('click', () => {
      searchOverlay.classList.add('active');
      setTimeout(() => {
        if (searchInput) searchInput.focus();
      }, 100);
    });

    if (closeSearch) {
      closeSearch.addEventListener('click', () => {
        searchOverlay.classList.remove('active');
      });
    }
  }

  // -------------------------
  // POSICIONAMIENTO DE TARJETA CAMPUS
  // -------------------------
  function placeCampusCard() {
    const card = document.querySelector('.campus .card');
    if (!card) return;

    if (window.innerWidth < 900) {
      card.style.position = 'static';
      card.style.transform = 'none';
      card.style.marginTop = '-80px';
      card.style.marginLeft = '12px';
    } else {
      card.style.position = 'absolute';
      card.style.left = '6%';
      card.style.top = '48%';
      card.style.transform = 'translateY(-50%)';
      card.style.marginTop = '0';
      card.style.marginLeft = '0';
    }
  }

  window.addEventListener('resize', placeCampusCard);
  placeCampusCard();

  // -------------------------
  // SLIDER DE NOTICIAS
  // -------------------------
  const slides = document.querySelectorAll('.news-slide');
  const dots = document.querySelectorAll('.dot');
  let currentSlide = 0;
  const slideInterval = 5000;

  function showSlide(index) {
    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    currentSlide = (index + slides.length) % slides.length;

    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
  }

  function nextSlide() {
    showSlide(currentSlide + 1);
  }

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      const slideIndex = parseInt(dot.getAttribute('data-slide'));
      showSlide(slideIndex);
      clearInterval(autoSlide);
      autoSlide = setInterval(nextSlide, slideInterval);
    });
  });

  let autoSlide;
  if (slides.length > 0) {
    autoSlide = setInterval(nextSlide, slideInterval);
  }

  // -------------------------
  // ANIMACIÓN DE CONTEO (ESTADÍSTICAS)
  // -------------------------
  const counters = document.querySelectorAll('.stat-number');
  const speed = 200;

  const startCounting = (counter) => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-target');
      const count = +counter.innerText.replace(/\D/g, ''); // Limpiar caracteres no numéricos
      const inc = target / speed;

      if (count < target) {
        counter.innerText = Math.ceil(count + inc).toLocaleString('es-ES');
        setTimeout(updateCount, 20);
      } else {
        counter.innerText = target.toLocaleString('es-ES');
      }
    };
    updateCount();
  };

  const observerOptions = { threshold: 0.5 };

  const statsObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        startCounting(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  counters.forEach(counter => statsObserver.observe(counter));

  // -------------------------
  // AGENDA SCROLL (BOTONES)
  // -------------------------
  const agendaScroller = document.getElementById('agendaScroller');
  const prevEventBtn = document.getElementById('prevEvent');
  const nextEventBtn = document.getElementById('nextEvent');

  if (agendaScroller && prevEventBtn && nextEventBtn) {
    const scrollAmount = 350;

    nextEventBtn.addEventListener('click', () => {
      agendaScroller.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    });

    prevEventBtn.addEventListener('click', () => {
      agendaScroller.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    });
  }

  // -------------------------
  // EGRESADOS (TARJETAS EN PILA)
  // -------------------------
  const alumniCards = document.querySelectorAll('.alumni-card');
  const alumniTexts = document.querySelectorAll('.alumni-text-block');
  const nextAlumniBtns = document.querySelectorAll('.next-alumni');
  const prevAlumniBtns = document.querySelectorAll('.prev-alumni');

  let currentAlumniIndex = 0;

  function updateAlumniDisplay() {
    alumniCards.forEach((card, index) => {
      card.classList.remove('card-active', 'card-next', 'card-behind');
      let position = (index - currentAlumniIndex + alumniCards.length) % alumniCards.length;

      if (position === 0) {
        card.classList.add('card-active');
      } else if (position === 1) {
        card.classList.add('card-next');
      } else {
        card.classList.add('card-behind');
      }
    });

    alumniTexts.forEach((text, index) => {
      text.classList.toggle('active', index === currentAlumniIndex);
    });
  }

  nextAlumniBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      currentAlumniIndex = (currentAlumniIndex + 1) % alumniCards.length;
      updateAlumniDisplay();
    });
  });

  prevAlumniBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      currentAlumniIndex = (currentAlumniIndex - 1 + alumniCards.length) % alumniCards.length;
      updateAlumniDisplay();
    });
  });

  if (alumniCards.length > 0) updateAlumniDisplay();

  // -------------------------
  // AÑO DEL FOOTER
  // -------------------------
  const yearSpan = document.getElementById('year');
  if (yearSpan) {
    yearSpan.innerText = new Date().getFullYear();
  }
})();